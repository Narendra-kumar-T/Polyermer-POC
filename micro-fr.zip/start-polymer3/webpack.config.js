const webpack = require('webpack');
const path = require("path");

module.exports = {
    entry: ["./index.html"],
    module: {
        rules: [
          {
            test: /\.html$/,
            use: [
              { loader: 'babel-loader' },
              { loader: 'polymer-webpack-loader' }
            ]
        },
          {
            test: /\.js$/,
            use: {
                loader: 'babel-loader',
            }
          }
        ]
    }
}

